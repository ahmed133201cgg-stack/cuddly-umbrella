# Rounds system

Flow: /duel → arena → Confirm GUI (Continue) → Rounds GUI (1-20) → request (with rounds) → accept → match.

- Each round ends when a player dies. Point to the winner, `rounds.break-seconds`, arena reset
  (placed blocks removed, broken map blocks restored, drops/projectiles cleared), kits re-given, countdown, next round.
- After the last round: higher score wins. Tie → one extra deciding round.
- /leave or disconnect → the WHOLE match ends, opponent wins (config `rounds.leave-counts-as-loss`).
- Stats (win/loss) recorded once per match. Rematch keeps the same number of rounds.
- Not reset between rounds: placed liquids (bucket), explosions, entities other than items/projectiles/xp/TNT.

## Resource pack
Numbers 1-20 are already merged into `src/main/resources/resourcepack/flags-pack.zip`
(textures/item/rounds, models/item/round_N.json, entries 2001..2020 in both items/paper.json and models/item/paper.json).
Keep `rounds.model-data-start: 2001` in config.yml. Flags still use 1000-1065.
