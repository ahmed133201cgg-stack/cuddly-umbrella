package com.duel.gui;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.utils.ItemUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Rounds picker — opened after the sender clicks "Continue" in DuelConfirmGUI.
 *
 *   Gray glass everywhere, 20 paper items (1..20) placed left → right, row by row.
 *   Each paper uses a custom model data from the resource pack
 *   (config: rounds.model-data-start → number 1, +1 for each next number).
 *   Clicking a number sends the duel request with that many rounds.
 */
public class RoundsGUI implements InventoryHolder {

    public static final int SIZE       = 45;
    public static final int MAX_ROUNDS = 20;
    public static final int SLOT_BACK  = 40;

    /** Slots for numbers 1..20: 7 per row, left to right (rows 2-4, inside the glass frame). */
    private static final int[] NUMBER_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33
    };

    private final DuelPlugin plugin;
    private final Player     sender;
    private final Player     target;
    private final Arena      arena;
    private final Inventory  inventory;

    public RoundsGUI(DuelPlugin plugin, Player sender, Player target, Arena arena) {
        this.plugin = plugin;
        this.sender = sender;
        this.target = target;
        this.arena  = arena;
        this.inventory = Bukkit.createInventory(this, SIZE, Component.text("Rounds"));
        populate();
    }

    private void populate() {
        ItemStack filler = ItemUtils.buildFiller(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < SIZE; i++) inventory.setItem(i, filler);

        for (int n = 1; n <= MAX_ROUNDS; n++) {
            inventory.setItem(NUMBER_SLOTS[n - 1], buildNumber(n));
        }
        inventory.setItem(SLOT_BACK, buildBack());
    }

    private ItemStack buildNumber(int n) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();

        int base = plugin.getConfig().getInt("rounds.model-data-start", 2001);
        meta.setCustomModelData(base + (n - 1));

        meta.displayName(Component.text(n + (n == 1 ? " Round" : " Rounds"))
                .color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Click to challenge " + target.getName())
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Arena: " + arena.getId())
                .color(NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildBack() {
        ItemStack item = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Cancel")
                .color(NamedTextColor.RED)
                .decoration(TextDecoration.BOLD, true)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Component.text("Click to cancel the challenge")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        item.setItemMeta(meta);
        return item;
    }

    /** @return the round count for a clicked slot, or -1 if the slot is not a number. */
    public static int roundsForSlot(int slot) {
        for (int i = 0; i < NUMBER_SLOTS.length; i++) {
            if (NUMBER_SLOTS[i] == slot) return i + 1;
        }
        return -1;
    }

    // ─────────────────────────────────────────
    //  API
    // ─────────────────────────────────────────

    public static void open(DuelPlugin plugin, Player sender, Player target, Arena arena) {
        RoundsGUI gui = new RoundsGUI(plugin, sender, target, arena);
        sender.openInventory(gui.getInventory());
    }

    public Player getSender() { return sender; }
    public Player getTarget() { return target; }
    public Arena  getArena()  { return arena; }

    @Override
    public Inventory getInventory() { return inventory; }
}
